"Modul zur Bestimmung der verbleibenden Restzeit der Waschmaschine"
import os

cwd = os.getcwd()

IMAGES_FOLDER = os.path.join('static/images')
IMAGES_READ_FOLDER = os.path.join(cwd, 'files/picture.jpeg')
#IMAGES_READ_FOLDER = os.path.join('files/picture.jpeg')
OUTPUT_FOLDER = os.path.join(cwd, 'files/output.txt')

def getTime():
    "Für /home/pi/share muss die entsprechende Adresse abgelegt werden, in der das Bild abgelegt wird und das output-file mit den gelesenen Daten"
    os.system('ssocr -T -f white -b black -d -1 -C /home/pi/share/picture.jpeg > OUTPUT_FOLDER')
    f=open('OUTPUT_FOLDER', 'r')

    data = f.read()
    "print(len(data))"
    "print(data)"
    "Ein ':' wird in den String eingefügt, damit an der Ausgabe nichts mehr verändert werden muss"
    data_neu = data[0]+':'+data[1]+data[2]
    print(data_neu)
    return data_neu

def main():
    getTime()

if __name__ == "__main__":
    # execute only if run as a script
    main()