#!/bin/python
import subprocess
from picamera import PiCamera
from time import sleep


def takePicture():


    camera = PiCamera()

    camera.start_preview()
    sleep(2)
    camera.capture('home/pi/share/picture.jpeg')
    camera.stop_preview()


def main():
    getTime()

if __name__ == "__main__":
    # execute only if run as a script
    main()