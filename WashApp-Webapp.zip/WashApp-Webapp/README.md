# WashApp
neue Änderungen:

- GetTime & takePic eingebunden als Funktionen
- Pfade geschrieben (Hinweis: bei der Datei GetTime.py muss der Pfad nach wie vor 'von Hand' eingegeben werden- das hab ich nicht anders hinbekommen.)
- zwei Buttons: update (wie vorher) und show machine (zeigt das Foto der Waschmaschine an)